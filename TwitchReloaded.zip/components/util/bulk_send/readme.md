# WebSocket Bulk Send Server

Web socket server that sends any client that connects to it a lot of message in
 a short time.

# Running

Install the node "ws" library

1. `npm install` from the build_send folder root
2. `node websocket_bulk_send_server.js`

The server is started on port 5000.
